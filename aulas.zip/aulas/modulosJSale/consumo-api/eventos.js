function inserir (){
    event.preventDefault();  // para a pagina não ser recarregado
    let dados ={
        item: input_item.value,
        quantidade: parseInt(input_quantidade.value),
    };
    
    fetch('http://localhost:8001/compras/', {
        method: 'POST',
        body: JSON.stringify(dados),
        headers: {
            'content-Type': 'application/json'      // colocasse as '' para ele reconhecer
        }
    })
        .then(resposta => resposta.json())
        .then(resposta => atualizarlista());

        form_add.reset();
}


 async function excluir(id){
    let resposta= confirm('voce quer excluir?')  // o confirme irar perguntar se o cliente vai querer 

        if (resposta !== true){
            return;
        }

      await  fetch('http://localhost:8001/compras/'+id,{    // await ele faz com que esse comando faz o fetch ele esperar 
        method: 'DELETE'
        
    });
    atualizarlista();
}

// function atualizarQuantidade(){
//     document.getElementById('numeros').innerHTML =tabela_compras.legth;
// }

function atualizarlista(){

    // let resposta = await fetch ('http://localhost:8000/compras') //isso só se coloca o fetch se for um GET
    // let resposta2 = await resposta.json()
    fetch ('http://localhost:8001/compras')
    .then(function(resposta){
        return resposta.json();
    })
    .then(function(lista){
            tabela_compras.innerHTML ='';
            lista.forEach(function (cadaItem){
               tabela_compras.innerHTML +=`
               <tr>
                    <td>${cadaItem.id}</td>
                    <td>${cadaItem.item}</td>
                    <td>${cadaItem.quantidade}</td>
                    <td>
                        <button class="btn btn-warning btn-sm">
                            Editar
                        </button>

                        <button onclick="excluir(${cadaItem.id})" class="btn btn-danger">
                            excluir
                        </button>

                       
                    </td>    
                </tr>    
               `; 
            });
        })
}

atualizarlista();

