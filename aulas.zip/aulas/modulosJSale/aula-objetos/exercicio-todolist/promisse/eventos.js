// const endpoint{
//     // aqui coloca duas api
//     // aqui coloca duas api
// }

// const promises = endpoint.map(url => fetch(url).then(res => res.json())) //aqiu ele me dara uma array de promessas

// Promise.all(promises)
//     .then(resutado =>{
//         console.log(resutado)
//     }); //aqui irá me passar todas as promessas de forma assincrona 

//     // async function a(){
//     //     let resutado = await promises

//     // }