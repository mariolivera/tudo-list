let variavelString = "glauras";

console.log(variavelString.charAt[4])

let numeroString = "1234"

let numero = parseFloat(numeroString.length)

console.log(numero)
console.log(numero.numeroString)
console.log(1+12+1212+122+'')


//indexof é um buscador de texto. e ele sempre retorna um numero se nao existir sempre vai retornar -1, ele não ler letras separadas só juntas, e retornar sempre a primeira vairiavel que ele achar.
//se vc colocar um numero ele busca apartir do numero ex: ("a",1) ele busca apartir da posicao 1, G= posiçao 0, L=posiçao 1, A=posiçao 2, U=posiçao 3, R=posiçao 4, A=posiçao 5, S=posiçao 6, a leitura dele sempre é feita resolvendo todas as variaveis dentro de cada string.
console.log(variavelString.indexOf("a"))
 

// o zero é considerado, mas os outros numeros, não é considerado.
// ex: (3, 5) ele retorna = r de glauros.
console.log(variavelString.substring(3, 5))

let Stringl = variavelString(substring.substring(1))
console.log()

    if(Stringl === variavelString(substring.substring(1))
    console.log ("texto")

// toda string já é um array
//substring sempre retorna texto, se for erro ela retorna vazio.
// estudar sobre strings, substring, indexof, slice é igual a substring, replace, split
//replace substitui a primeira ocorencia que ele encontra, para substituir todas as ocorencia usa-se replaceAll e ele sempre retorna texto, e da para fazer com espaço ex: (" " , ""). aqui ele subistitui o espaço pelo vazio.
//splite sempre retorna um array de string. se juntar o .splint com o .join vc consegue simular um replaceAll.
//trim apaga os espaços da borda
//.join ele coloca uma string entre as outras strings 
// lastindexof ele ler da esquerda para direita.
//indexof retorna sempre um numero, não da para colocar um .length depois de um parentese por isso, Ex: mareiaaa indexof("a").length. isso não é possivel por causa da regra de que o indexof só retorna numero.

exemplo do letroco

let palavradodia = "sorte"
let tentativa = "noite" 

palavradodia=[0] tentativa=[0]
palavradodia=[1] tentativa=[1]
palavradodia=[2] tentativa=[2]
palavradodia=[3] tentativa=[3]
palavradodia=[4] tentativa=[4]

for(i= 0, i<5,i++){
    console.log (palavradodia=tentativa)
}

let palavradodia = "sorte"
let tentativa = "noite"

palavradodia.indexOf(tentativa[0]) // = -1 vermelho
palavradodia.indexOf(tentativa[1]) // = 1 verde
palavradodia.indexOf(tentativa[2]) // 3 amarelo
palavradodia.indexOf(tentativa[3])
palavradodia.indexOf(tentativa[4])

for(i= 0, i<5,i++){
    if(i=-1)//colocar um consolelog, com as configurações do css vermelho{

    }else if(i=1)//colocar um consolelog, com as configurações do css verde{
        else // colocar um consolelog, com as configurações do css amarelo
    }




