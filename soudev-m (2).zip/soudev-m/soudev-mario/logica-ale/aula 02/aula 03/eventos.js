let turma =[
'aluno1',
'aluno2',
'aluno3',
'aluno4',
];

turma[3] += aluno6


let quantidade = turma.length;

turma.push('aluno5');
for (let n = 0; n <quantidade; n++){
     document.write(`${turma[n]}+<br>`); 
}
// tambem pode ser assim for (let n = 0; n <=4; n++){  document.write(turma[n]+'<br>'); } só que não é mais usado
// essa função irar jogar o aluno 5 para dentro. tambem pode ser assim turma[5]='aluno5'





 
// let nome = aluno1
// let cidade =fortaleza
// let idade = 20
// document.write(
    // `oi meu nome é ${nome}, moro em ${cidade} e tenho ${idade}`
// )