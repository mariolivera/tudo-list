let x = 1000; 

do {// usar o do e o whaile para ter a certeza de fazer pelo menos uma vez, ele não é uma opção segura.
    musica1.innerHTML += 'Carro Pancadão Hey <br>'

    x++;
} while(x <= 10);

for (let n=1; n <=10; n++){
    musica2.innerHTML += '40028922 é o funk do yudi que vai da o playstation 2<br>'
}