aluno:

let nome ='nome';
let email= 'email@hotmail.com';
let ddata_de_nascimento = '10/03/2002';//não é recomentado usar idade, pois o numero se mantem, o recomendado é colocar data de nascimento//
let sexo = 'prefiro não informar';
let endereço ='rua x 123'
let estar_matriculado = true;
let saldo_bancario = 100.00;