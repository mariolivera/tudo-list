function mark() {
  alert("marquei");
}