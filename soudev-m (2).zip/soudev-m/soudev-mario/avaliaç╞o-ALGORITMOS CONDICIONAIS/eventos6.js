//6- Escreva um algoritmo que lê dois valores booleanos lógicos e então determina se ambos são
//VERDADEIROS ou FALSOS. 

let = x(true) && y(true)
console.log()

//continuar