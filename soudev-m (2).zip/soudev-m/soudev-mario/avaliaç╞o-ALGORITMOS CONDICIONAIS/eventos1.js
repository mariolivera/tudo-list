//1) Faça um algoritmo que leia os valores A, B, C e imprima na tela se a soma de A + B é menor
//que C.
 